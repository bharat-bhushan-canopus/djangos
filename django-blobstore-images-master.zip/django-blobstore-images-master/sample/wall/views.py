from django import http
from google.appengine.ext import blobstore
from google.appengine.api import images

from google.appengine.ext import ndb

from sample.wall.blobstore import get_uploads
from sample.extensions.views import BaseView
from sample.extensions.paging import Pager


class ImageInfo(ndb.Model):

    serving_url = ndb.StringProperty(indexed=False)

    alt = ndb.StringProperty(indexed=False)

    blob_key = ndb.BlobKeyProperty(indexed=False)

    content_type = ndb.StringProperty(indexed=False)

    original_filename = ndb.StringProperty(indexed=False)

    created = ndb.DateTimeProperty(auto_now_add=True)


class HomeHandler(BaseView):

    def get(self):

        page = int(self.request.GET.get('p', 1))
        query = ImageInfo.query().order(-ImageInfo.created)
        pager = Pager(query=query, page=page)
        _images, cursor, more = pager.paginate(page_size=50)

        return self.render_to_response('home.html', context={
            'upload_url': blobstore.create_upload_url(success_path='/upload-finalize'),
            'images': _images,
            'more': more,
            'next_page': page + 1,
            'previous_page': page - 1
        })


class UploadFinalizeHandler(BaseView):

    def post(self):
        image_alt = self.request.POST.get('image_alt')
        image_alt = image_alt.strip()

        for upload in get_uploads(self.request, 'image'):
            blob_key = upload.key()

            info = ImageInfo(
                serving_url=images.get_serving_url(blob_key),
                alt=image_alt,
                blob_key=blob_key,
                original_filename=upload.filename,
                content_type=upload.content_type
            )
            info.put()

            return http.HttpResponseRedirect("/")
