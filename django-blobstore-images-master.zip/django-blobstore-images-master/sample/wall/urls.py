from django.conf.urls import patterns, url
from sample.wall import views

urlpatterns = patterns('',
    url(r'^$', views.HomeHandler.as_view(), name='home'),
    url(r'^upload-finalize$', views.UploadFinalizeHandler.as_view(), name='reserve-finalize'),
)