from google.appengine.ext.webapp import util

from django.core.handlers import wsgi
app = wsgi.WSGIHandler()


def main():
    """Main program. Run the Django WSGIApplication."""
    util.run_wsgi_app(app)


if __name__ == '__main__':
    main()
