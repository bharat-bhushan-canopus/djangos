## Quickly getting started

Create your virtual environment and clone this repo.

Install Google Cloud SDK: https://cloud.google.com/sdk/
<pre><code>curl https://sdk.cloud.google.com | bash
</code></pre>

Install Requirements - PIL and Django 1.5 (At this time it is the latest supported Django on AppEngine)
<pre><code>pip install -r requirements.txt
</code></pre>

### Run it!

Switch to your folder where you cloned this repo and run it using dev_appserver.py. This assumes you followed the instructions
and have the Google tools in your Python path or virtual environment
<pre><code>dev_appserver.py .
</code></pre>

## High Level Concepts

What makes this so awesome is the power of blobstore and the images API from Google. Hosting images in this way is the most
optimal and probably cost effective way of doing it since your app instances aren't used to fetch or store any of the
images. Normal instance timeouts and request sizes don't apply.

* No file upload handlers configured. You don't need to use the memory upload handler and cause your instances to constantly
reboot because they are running through their maximum memory.
* Easily kick off deferred jobs to further manipulate images after upload if necessary in the finalize handler.
* Post all of your form data with the file upload, any other data is passed to your finalize handler along with the blob info.
* Use images api to serve directly from blobstore and take advantage of resize and crop url manipulation.

See: https://cloud.google.com/appengine/docs/python/images/functions#Image_get_serving_url

## Questions?

https://github.com/caoimhghin/django-blobstore-images/issues/new